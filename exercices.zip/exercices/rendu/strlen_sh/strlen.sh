echo $FT_LINE | tr -d "\n" | wc -c | tr -d " "
