echo ${#FT_LINE}
