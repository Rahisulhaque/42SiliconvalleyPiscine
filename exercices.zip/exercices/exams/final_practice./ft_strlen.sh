echo $FT_LINE | awk "{print length($0)}"
