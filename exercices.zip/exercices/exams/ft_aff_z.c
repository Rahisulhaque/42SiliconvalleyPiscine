#include <unistd.h>

void	aff_z(char *str)
{
	str = str;
	write(1, "z\n", 2);
}
