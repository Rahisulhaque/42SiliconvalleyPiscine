char *ft_strcapitalize(char *str)
{
	i
