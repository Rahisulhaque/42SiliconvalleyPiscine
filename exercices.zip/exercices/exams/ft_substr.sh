echo $FT_LINE | cut -c 6-
